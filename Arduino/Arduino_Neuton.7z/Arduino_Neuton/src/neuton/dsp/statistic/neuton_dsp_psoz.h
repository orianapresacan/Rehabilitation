/**
 *
 * @defgroup neuton_dsp_statistic_psot Percentage of signal over zero
 * @{
 * @ingroup neuton_dsp_statistic
 *
 * @brief
 *
 */
#ifndef _NEUTON_DSP_STAT_PSOZ_FUNCTIONS_H_
#define _NEUTON_DSP_STAT_PSOZ_FUNCTIONS_H_

#include "neuton_dsp_psot.h"

#ifdef   __cplusplus
extern "C"
{
#endif

/**
 * @brief Calculates Percentage of signal over zero in a floating-point vector.
 *
 * @param[in]   p_input   Pointer to the input vector
 * @param[in]   num       Number of samples in input vector
 *
 * @return  neuton_f32_t  Percentage of signal over zero in the vector
 */
#define neuton_dsp_psoz_f32(p_input, num)               neuton_dsp_psot_f32((p_input), (num), 0.f)

/**
 * @brief Calculates Percentage of signal over zero in a floating-point vector ​​using values ​​in increments of 'stride'.
 *
 * @param[in]   p_input   Pointer to the input vector
 * @param[in]   num       Number of samples with 'stride' in input vector
 * @param[in]   stride    Vector element offset stride
 *
 * @return  neuton_f32_t  Percentage of signal over zero in the vector
 */
#define neuton_dsp_psoz_f32_s(p_input, num, stride)     neuton_dsp_psot_f32_s((p_input), (num), stride, 0.f)

/**
 * @brief Calculates Percentage of signal over zero in a INT8 fixed-point vector.
 *
 * @param[in]   p_input   Pointer to the input vector
 * @param[in]   num       Number of samples in input vector
 *
 * @return  neuton_i16_t  Percentage of signal over zero in the vector, multiplied by NEUTON_PERCENTAGE_TO_INT_FACTOR
 */
#define neuton_dsp_psoz_i8(p_input, num)               neuton_dsp_psot_i8((p_input), (num), 0)

/**
 * @brief Calculates Percentage of signal over zero in a INT8 fixed-point vector ​​using values ​​in increments of 'stride'.
 *
 * @param[in]   p_input   Pointer to the input vector
 * @param[in]   num       Number of samples with 'stride' in input vector
 * @param[in]   stride    Vector element offset stride
 *
 * @return  neuton_i16_t  Percentage of signal over zero in the vector, multiplied by NEUTON_PERCENTAGE_TO_INT_FACTOR
 */
#define neuton_dsp_psoz_i8_s(p_input, num, stride)     neuton_dsp_psot_i8_s((p_input), (num), stride, 0)

/**
 * @brief Calculates Percentage of signal over zero in a INT16 fixed-point vector.
 *
 * @param[in]   p_input   Pointer to the input vector
 * @param[in]   num       Number of samples in input vector
 *
 * @return  neuton_i16_t  Percentage of signal over zero in the vector, multiplied by NEUTON_PERCENTAGE_TO_INT_FACTOR
 */
#define neuton_dsp_psoz_i16(p_input, num)              neuton_dsp_psot_i16((p_input), (num), 0)

/**
 * @brief Calculates Percentage of signal over zero in a INT16 fixed-point vector ​​using values ​​in increments of 'stride'.
 *
 * @param[in]   p_input   Pointer to the input vector
 * @param[in]   num       Number of samples with 'stride' in input vector
 * @param[in]   stride    Vector element offset stride
 *
 * @return  neuton_i16_t  Percentage of signal over zero in the vector, multiplied by NEUTON_PERCENTAGE_TO_INT_FACTOR
 */
#define neuton_dsp_psoz_i16_s(p_input, num, stride)     neuton_dsp_psot_i16_s((p_input), (num), stride, 0)

#ifdef   __cplusplus
}
#endif

#endif /* _NEUTON_DSP_STAT_PSOZ_FUNCTIONS_H_ */

/**
 * @}
 */
